# 数据目录

当前 night 实验所需图像均已在项目内：`train/day/night` 有 7,719 张真实白天图，`train/weather/night` 有 7,719 张 Qwen 生成夜图；`svox/images/test/gallery` 有 17,166 张白天图库图，`queries_night` 有 823 张真实夜间查询图。

## 配对清单

`train/manifest.jsonl` 已从历史 Qwen 元数据生成。每行显式记录 `sample_id`、`city`、`place_id`、相对当前清单目录的 `source_path` / `output_path` 和 SHA-256。训练时不访问外部 WORKSPACE。若重新搬运或增补图像，先重建并核验清单：

```bash
python scripts/build_night_manifest.py \
  --metadata /home/admin123/github/WORKSPACE/outputs/qwen_curriculum/images/metadata.jsonl \
  --verify-hashes
```

`--metadata` 只是原始元数据位置示例，换机器时改成实际路径。不得仅凭地点或相似文件名猜测图对；Qwen 夜图文件名与白天源图文件名不同。

## 地点隔离

`scripts/make_night_split.py` 默认读取本项目 `third_party/salad/configs/splits/ccr_reserved_places.json`，先排除历史 validation/calibration 保留地点，再以 `(city, place_id)` 为组生成 5% 合成验证集。

```bash
python scripts/make_night_split.py
```

生成的 `splits/night_train.jsonl` 有 7,263 对、`night_val.jsonl` 有 385 对，另有 `night_split.json` 记录输入哈希与划分参数、`heldout_places.json` 汇集保留地点。训练清单中的路径已改为相对 `splits/`，可直接传给 `--manifest`。`heldout_places.json` 包含与当前 checkpoint 的 Stage2B 校准绑定的全部 12 个地点，建议训练时再传 `--exclude-places data/splits/heldout_places.json` 作防漏保护。

## 真实天气评估

`DarkDriving_Base/` 已完成坏图成对移出与完整日夜图组去重，保留 9,520 对可读图像。目录内有 `pairs.csv`、`manifest.jsonl`、校验结果和使用说明；独立加载器与复查命令见 [DarkDriving 使用说明](../docs/DARKDRIVING.md)。该数据集未自动加入现有训练清单。

SVOX 不需要手工生成 `place_id` CSV。`scripts/evaluate_svox.py` 从其 `@UTM_Easting@UTM_Northing@...` 文件名读取坐标，按 25 米半径判正。使用 `python scripts/evaluate_svox.py --check-data` 可先检验完整测试目录。普通自有数据若具备 `path,place_id` CSV，可使用通用 `scripts/evaluate.py`；它的同 ID 判正方式不能替代 SVOX 的地理半径协议。
