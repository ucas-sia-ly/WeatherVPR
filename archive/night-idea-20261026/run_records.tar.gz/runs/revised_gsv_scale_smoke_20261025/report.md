# Independent GSV Source scale: G1/G2 x A/B

Seed 42; four fresh original-Day initializations. Fixed main/Source/real-view budgets.

| Cell | Updates | Available Source places | Exposed Source places | Exposed new places vs G1 | Dev R@1 | R@5 | R@10 |
|---|---:|---:|---:|---:|---:|---:|---:|
| G1_A | pending | pending | pending | pending | smoke/pending | smoke/pending | smoke/pending |
| G1_B | pending | pending | pending | pending | smoke/pending | smoke/pending | smoke/pending |
| G2_A | pending | pending | pending | pending | smoke/pending | smoke/pending | smoke/pending |
| G2_B | pending | pending | pending | pending | smoke/pending | smoke/pending | smoke/pending |

B-A within each scale and G2-G1 within each arm have per-query TopK repaired/regressed IDs in [summary.json](summary.json).

Main and same-scale Source comparability: {}

Single exploratory seed and development only; independent Source G1 differs from historical same-batch Source. Available places and actual exposed places are distinct. No significance or generalization claim.

Source scaling changes its available positive samples and fixed Source-only candidate keys. Qwen samples and fixed bank remain unchanged. Stream checks compare IDs, places and augmentation operation counters, not independent augmented-image byte hashes.

[Frozen plan](experiment_plan.json) · [Status](status.json)
