from pathlib import Path
import json
import subprocess
import sys

root = Path('/home/admin123/github/WeatherVPR')
out = root/'runs/revised_external_night_preflight_20261025'
out.mkdir(exist_ok=True)
commands = {
    'svox_test': ['scripts/evaluate_svox.py', '--split', 'test', '--check-data'],
    'tokyo247': ['scripts/evaluate_night_benchmarks.py', '--dataset', 'tokyo247', '--check-data'],
    'robotcar_night': ['scripts/evaluate_night_benchmarks.py', '--dataset', 'robotcar-public', '--condition', 'night', '--check-data'],
    'robotcar_night_rain': ['scripts/evaluate_night_benchmarks.py', '--dataset', 'robotcar-public', '--condition', 'night-rain', '--check-data'],
}
for name, command in commands.items():
    result = subprocess.run([sys.executable, *command], cwd=root, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    payload = json.loads(result.stdout)
    (out/(name+'.json')).write_text(json.dumps(payload,indent=2)+'\n')
    print(name, {key: payload.get(key) for key in ('num_references','num_queries','num_queries_without_positives')},flush=True)
