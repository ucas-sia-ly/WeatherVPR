# Frozen external night evaluation

Exploratory external comparison of every completed final model; no tuning or winner selection.

State: complete; 52/52 fresh evaluations.

| Model | svox_test | tokyo247_night | robotcar_night | robotcar_night_rain |
|---|---:|---:|---:|---:|
| Original Day | 763/810/816 / 823 | 91/95/98 / 105 | 179/187/190 / 197 | 214/216/218 / 224 |
| seed42_A | 760/813/816 / 823 | 88/96/100 / 105 | 179/188/190 / 197 | 213/216/217 / 224 |
| seed42_B | 764/813/816 / 823 | 89/96/98 / 105 | 179/187/190 / 197 | 213/215/218 / 224 |
| seed42_C | 762/812/816 / 823 | 88/96/98 / 105 | 179/188/191 / 197 | 213/215/217 / 224 |
| seed43_A | 759/812/816 / 823 | 89/96/99 / 105 | 178/188/191 / 197 | 213/216/218 / 224 |
| seed43_B | 763/813/816 / 823 | 89/96/99 / 105 | 179/187/190 / 197 | 213/214/217 / 224 |
| seed43_C | 761/812/816 / 823 | 88/96/98 / 105 | 178/187/192 / 197 | 213/216/218 / 224 |
| seed44_A | 762/811/816 / 823 | 89/96/100 / 105 | 178/188/192 / 197 | 213/216/219 / 224 |
| seed44_B | 762/813/816 / 823 | 89/96/98 / 105 | 179/187/190 / 197 | 213/216/218 / 224 |
| seed44_C | 763/812/816 / 823 | 89/96/98 / 105 | 178/188/192 / 197 | 213/216/219 / 224 |
| G1_A | 761/810/816 / 823 | 89/96/100 / 105 | 178/188/190 / 197 | 213/216/217 / 224 |
| G1_B | 763/812/816 / 823 | 89/96/98 / 105 | 180/187/190 / 197 | 213/215/218 / 224 |
| G2_A | 761/812/816 / 823 | 90/96/100 / 105 | 178/188/190 / 197 | 213/216/218 / 224 |
| G2_B | 763/812/816 / 823 | 89/96/98 / 105 | 179/187/190 / 197 | 213/215/218 / 224 |

Cells show correct queries at R@1/R@5/R@10, followed by query count.

Three-seed means/sample standard deviations and paired repairs/regressions at every TopK are in summary.json.

SVOX/Tokyo/RobotCar protocols have been inspected historically; these are not newly blind tests. RobotCar uses public train poses as evaluation only, not the official benchmark. Tokyo local v3 query images have not been independently byte-verified against v2.

SF-XL remains untouched; Aachen/official RobotCar tests lack local public retrieval ground truth

No training, fusion, TTA, external-score hyperparameter search, or historical result substitution.
