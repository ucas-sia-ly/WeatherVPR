from pathlib import Path
import hashlib
import json

root = Path('/home/admin123/github/WeatherVPR')
out = root/'outputs/revised_plan_20261025'
p0 = json.loads((root/'runs/revised_stage1_multiseed_20261025/summary.json').read_text())
scale = json.loads((root/'runs/revised_gsv_scale_20261025/summary.json').read_text())
p1 = json.loads((out/'domain_coverage/report.json').read_text())
assert p0['state'] == scale['state'] == 'complete'
assert all(all(check.values()) for check in p0['integrity'].values())
assert all(scale['integrity'].values())
assert p1['optimizer_updates'] == p1['recall_evaluations'] == 0
assert p1['model_state_sha256_before'] == p1['model_state_sha256_after']
records = scale['cells']
lines = ['# 修订方案落地与首轮结果', '',
    '**已完成方案调整、训练数据审计、三 seed A/B/C、冻结域覆盖诊断，以及独立 Source 的 G1/G2×A/B 首轮完整训练。** 新训练与评估均使用固定预算，只评估 SVOX dev。', '',
    '## H1：真实配对有小幅 Top-1 排序增量，同时存在 Top-5 退化', '',
    '三个 seed 的 B−A Top-1 为 +5/+7/+2 张，平均 +0.665 个百分点；Top-5 为 −1/−2/−2。所有 Top-1 修复原本已在 A 的前五名内，不能称检索候选覆盖提升。B 仍为可选实验，未设为默认。见 [多 seed 结果](p0_multiseed.md)、[逐 Query 复核](p0_review.md)、[亮度/空间分层](stage1_strata.md)。', '',
    '## H2：已测量真实/合成覆盖，暂不训练真实供体', '',
    '每域 512 张训练图，共 2,560 张；原始 Day 前缀及 SALAD 全冻结，0 次更新、0 次 Recall。block 7 的合成联合参考阈值包含率：DarkDriving94.92%、NightCity95.12%、BDD65.62%。BDD 的差异仍混有道路、视场、相机与亮度；PCA32只保留参考方差54%，参考也未覆盖 camera-augmented Qwen 的全部训练输入。该测量不是风格因果证明。', '',
    '已对相同64张接收图、等量供体、相同掩码和λ测量真实ΔF及描述符/SALAD变化，实际29张启用；未根据Recall调强度。结合25张训练样本的有限内容检查，当前证据不足以打开真实供体TFS、GUIDE或配对残差。见 [定量与图像报告](domain_coverage/report.md)。', '',
    '## H3：独立 Source 地点规模首轮', '',
    '四组从原始Day全新初始化，seed42；每组908次更新、7,263个主Qwen视图、1,816个Source视图；B再有1,816个真实辅助视图。Source使用该档独立bank，主Qwen流与bank保持一致。原始Day开发命中数为621/668/674。', '',
    '| 单元 | 可用Source地点 | 实际Source地点 | 实际新增地点 | R@1 / R@5 / R@10 命中数 |',
    '|---|---:|---:|---:|---|']
for cell in ('G1_A','G1_B','G2_A','G2_B'):
    rec = records[cell]; t = rec['training']; e = rec['evaluation']['night']
    hits = ' / '.join(str(e['hits'][f'R@{k}']) for k in (1,5,10))
    lines.append(f"| {cell} | {t['known_source_training_places']} | {t['exposed_source_places']} | {t['exposed_new_places_over_G1']} | {hits} |")
lines += ['', '| 比较 | ΔTop-1 | ΔTop-5 | ΔTop-10 | Top-1修复 / 退化 |', '|---|---:|---:|---:|---:|']
comparisons = (('G1_A','G1_B'),('G2_A','G2_B'),('G1_A','G2_A'),('G1_B','G2_B'))
for before,after in comparisons:
    diff = [records[after]['evaluation']['night']['hits'][f'R@{k}']-records[before]['evaluation']['night']['hits'][f'R@{k}'] for k in (1,5,10)]
    change = scale['paired_changes'][after+'_vs_'+before]['R@1']
    lines.append(f"| {after}−{before} | {diff[0]:+d} | {diff[1]:+d} | {diff[2]:+d} | {change['repaired_count']} / {change['regressed_count']} |")
new_places = records['G2_A']['training']['exposed_new_places_over_G1']
lines += ['',
    f'G2池为17,263张Day、11,441个地点；一个固定预算epoch实际只曝光1,816个Source地点，其中{new_places}个不在G1。主Qwen已覆盖6,441个G1地点，故实际Student训练地点并集为{6441+new_places}，不能写成11,441个地点都经过Night训练。', '',
    '规模轴同时改变Source可采样地点和Source-only固定候选bank；采样量与优化预算匹配，但不能将差异单独归因于地理多样性。独立G1与旧同batch Source的A/B不是同一个实验底座。单seed、同一开发集的几张差异不足以确认“大规模GSV与真实监督互补”，不因本轮结果追加已看过test的搜索。完整配置/权重哈希/配对Query见 [规模结果](../../runs/revised_gsv_scale_20261025/report.md) 和 [JSON](../../runs/revised_gsv_scale_20261025/summary.json)。', '',
    '## 实现、资源与保留限制', '',
    '新增训练池来源清单、CSV/图像/排除证据签名、可复现域覆盖缓存、独立Source采样及bank、串行队列、多seed/配对Top-k/亮度与200m空间分组统计。GSV原朝向值−11到731按原SALAD文件规则保留。321项检查通过，包含实际训练循环的梯度累积、尾批、多正样本与RNG隔离数值对照；四单元真实数据短跑及完整预算亦通过。', '']
new = [v['training'] for n,v in p0['records'].items() if not n.startswith('seed42')]
new += [v['training'] for v in records.values()]
ram = max(v['memory_guard']['peak_cgroup_bytes_kernel'] for v in new)/2**30
cuda = max(v.get('peak_cuda_allocated_bytes') or 0 for v in new)/2**30
lines += [f'本轮10次新完整训练均通过7GiB RAM上限、6GiB high、2GiB系统余量保护，无OOM；完整训练最大任务RAM {ram:.2f}GiB，最大GPU已分配张量 {cuda:.2f}GiB。保持microbatch4×累积2以保留对比批次语义，采用GPU bank、4workers、prefetch1及关闭重计算。实际内存峰值不是设备整体驻留或利用率，缓存构建开销另见短跑日志。', '',
    'DarkDriving的9,520条接受记录均为automatic；9,286个精确内容组不等于独立路线，24组跨文件前缀。现有审核只有一个全场地scene_group，实际为文件行内循环，未完成路线/近重复认证。保留该协议复核H1，后续修改采样须单独对照。', '',
    '本地SF-XL的466张night query仅盘点为最终测试候选，未提取描述符、未计算Recall、未按失败样本选模型；完整协议与历史使用核验仍待完成。未重新运行SVOX test/Tokyo247/RobotCar。', '',
    '[主方案](../../idea.md) · [实现与复现](../../docs/REVISED_RESEARCH_IMPLEMENTATION.md) · [数据清单](data_inventory/inventory.json) · [DarkDriving审计](darkdriving_source_audit.json) · [测试保留记录](reserved_night_test.json)', '']
(out/'report.md').write_text('\n'.join(lines))
manifest = {'kind':'revised_research_execution','status':'complete_authorized_round',
    'proposal_sha256':hashlib.sha256((root/'WeatherVPR_idea_revised_20261025_copy.md').read_bytes()).hexdigest(),
    'tests_passed':321,'new_full_training_runs':10,'new_seed_runs':6,'scale_runs':4,
    'p0_summary':'runs/revised_stage1_multiseed_20261025/summary.json',
    'p1_report':'outputs/revised_plan_20261025/domain_coverage/report.json',
    'scale_summary':'runs/revised_gsv_scale_20261025/summary.json',
    'valid_smoke_summary':'runs/revised_gsv_scale_smoke_v3_20261025/summary.json',
    'external_test_evaluations_this_round':0,'domain_diagnostic_optimizer_updates':0,
    'peak_full_training_ram_gib':ram,'peak_full_training_cuda_allocated_gib':cuda,
    'conditional_modules':{'real_donor_tfs':False,'guide_diffusion':False,'paired_residual':False},
    'research_not_proven':['certified_DarkDriving_route_independence','causal_pairing_advantage',
        'cross_domain_generalization','large_GSV_real_pair_complementarity'],
    'next_conditional_work':['training-only camera/road/content controls and Day alignment diagnostic',
        'predeclare scale multi-seed confirmation if further pursued','audit reserved night test protocol before final evaluation']}
(out/'execution.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
idea = root/'idea.md'
text = idea.read_text()
assert '## 16.' not in text
text += '\n## 16. 本轮实际执行状态（2026-10-25）\n\n'
text += '方案调整、P0三个seed复核、P1冻结域诊断、独立Source的G1/G2×A/B首轮训练均已完成，见 [总报告](outputs/revised_plan_20261025/report.md)。321项检查通过，所有新完整训练为908次更新。\n\n'
text += 'H1：B−A的Top-1为+5/+7/+2，平均+0.665个百分点；Top-5均下降，修复均来自原本前五名，属于候选内排序信号。H2：BDD存在范围外样本，但内容/相机混杂未解除；真实供体TFS、GUIDE和配对残差保持关闭。\n\n'
text += f'H3：G2提供11,441个可用Source地点，本轮实际曝光1,816个Source地点，其中{new_places}个新增；实际Student地点并集为{6441+new_places}。各组Top-k和修复/退化见总报告，不以单seed几张变化确认规模互补。\n\n'
text += '正式路线/近重复认证和未触碰夜间测试的协议审计仍未完成。这些研究证据限制不被工程测试通过所替代；后续条件路线不自动启动。\n'
idea.write_text(text)
print('Wrote final report, execution manifest and idea status')
