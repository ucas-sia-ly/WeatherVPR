# Frozen external night evaluation

Exploratory external comparison of every completed final model; no tuning or winner selection.

State: planned; 0/52 fresh evaluations.

| Model | svox_test | tokyo247_night | robotcar_night | robotcar_night_rain |
|---|---:|---:|---:|---:|
| Original Day | pending | pending | pending | pending |
| seed42_A | pending | pending | pending | pending |
| seed42_B | pending | pending | pending | pending |
| seed42_C | pending | pending | pending | pending |
| seed43_A | pending | pending | pending | pending |
| seed43_B | pending | pending | pending | pending |
| seed43_C | pending | pending | pending | pending |
| seed44_A | pending | pending | pending | pending |
| seed44_B | pending | pending | pending | pending |
| seed44_C | pending | pending | pending | pending |
| G1_A | pending | pending | pending | pending |
| G1_B | pending | pending | pending | pending |
| G2_A | pending | pending | pending | pending |
| G2_B | pending | pending | pending | pending |

Cells show correct queries at R@1/R@5/R@10, followed by query count.

Three-seed means/sample standard deviations and paired repairs/regressions at every TopK are in summary.json.

SVOX/Tokyo/RobotCar protocols have been inspected historically; these are not newly blind tests. RobotCar uses public train poses as evaluation only, not the official benchmark. Tokyo local v3 query images have not been independently byte-verified against v2.

SF-XL remains untouched; Aachen/official RobotCar tests lack local public retrieval ground truth

No training, fusion, TTA, external-score hyperparameter search, or historical result substitution.
