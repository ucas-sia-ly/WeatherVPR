"""Inspect serialized smoke weights without constructing another VPR model."""
from pathlib import Path
import hashlib
import json
import re
import torch
from safetensors import safe_open

root=Path(__file__).resolve().parent
checkpoint=Path('weights/dino_salad.ckpt')
base=torch.load(checkpoint,map_location='cpu',weights_only=False)
state=base.get('state_dict',base)
backbone={k.removeprefix('backbone.'):v for k,v in state.items() if k.startswith('backbone.')}
assert backbone
sha=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
summary={'kind':'technical smoke only; no Recall measured', 'checkpoint_sha256':sha, 'arms':{}}
logs={}
for arm,directory in [('A','A_final'),('B','B'),('C','C')]:
    path=root/directory
    meta=json.loads((path/'adapter.json').read_text())
    config=json.loads((path/'training_config.json').read_text())
    log=[json.loads(line) for line in (path/'training_log.jsonl').read_text().splitlines()]
    plan=json.loads((path/'experiment_plan.json').read_text())
    assert meta['checkpoint_sha256']==sha
    assert meta['optimizer_steps']==2 and len(log)==3
    assert log[-1]['optimizer_step']==2 and log[-1]['accumulation_count']==0
    assert meta['full_train_scope']['block_indices']==[8,9,10,11]
    changed,frozen=[],[]
    with safe_open(path/'adapter.safetensors',framework='pt',device='cpu') as weights:
        assert set(weights.keys())==set(backbone)
        for key in weights.keys():
            value=weights.get_tensor(key)
            assert torch.isfinite(value).all(), (arm,key)
            if torch.equal(value,backbone[key]):
                frozen.append(key)
            else:
                match=re.match(r'model\.blocks\.(\d+)\.',key)
                assert match and int(match.group(1)) in (8,9,10,11), (arm,key)
                changed.append(key)
    changed_blocks=sorted({int(re.match(r'model\.blocks\.(\d+)\.',key).group(1)) for key in changed})
    assert changed_blocks==[8,9,10,11]
    expected={'qwen':6,'source_night':3,'real_auxiliary':6 if arm=='B' else 0,'synthetic_auxiliary':6 if arm=='C' else 0}
    assert meta['student_views']==expected
    assert meta['auxiliary']['enabled']==(arm!='A')
    if arm!='A':
        assert all(row['auxiliary_samples']==2 and row['auxiliary_weighted_loss']>0 for row in log)
        assert log[0]['auxiliary_gradient']['auxiliary_norm']>0
    memory=[json.loads(line) for line in (root/(directory+'.memory.jsonl')).read_text().splitlines()][-1]
    assert memory['returncode']==0 and memory['memory_events']['oom_kill']=='0'
    summary['arms'][arm]={
        'directory':str(path),'changed_tensors':len(changed),'unchanged_tensors':len(frozen),
        'changed_blocks':changed_blocks,'frozen_parameters_equal_original':True,
        'updates':meta['optimizer_steps'],'student_views':meta['student_views'],
        'main_stream_sha256':meta['main_stream_sha256'],
        'peak_ram_gib':memory['peak_cgroup_bytes_kernel']/1024**3,
        'elapsed_seconds':memory['elapsed_seconds'],
        'auxiliary_initial_loss':log[0]['auxiliary_loss'],
        'auxiliary_initial_gradient':log[0]['auxiliary_gradient'],
        'plan_train_code_sha256':plan['train_code_sha256'],
    }
    logs[arm]=log
for arm in ('B','C'):
    for a,b in zip(logs['A'],logs[arm]):
        for key in ('main_sample_indices','source_sample_indices','augmentation','source_night_augmentation'):
            assert a[key]==b[key], (arm,key)
    for key in ('global_loss','contrast','relation_loss','source_night_loss'):
        assert abs(logs['A'][0][key]-logs[arm][0][key])<1e-5, (arm,key)
assert len({row['main_stream_sha256'] for row in summary['arms'].values()})==1
assert len({row['plan_train_code_sha256'] for row in summary['arms'].values()})==1
summary['shared_main_stream_and_initial_losses']=True
(root/'verification.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
print(json.dumps(summary,indent=2,ensure_ascii=False))
