# Independent GSV Source scale: G1/G2 x A/B

Seed 42; four fresh original-Day initializations. Fixed main/Source/real-view budgets.

| Cell | Updates | Available Source places | Exposed Source places | Exposed new places vs G1 | Dev R@1 | R@5 | R@10 |
|---|---:|---:|---:|---:|---:|---:|---:|
| G1_A | 908 | 6441 | 1816 | 0 | 621/702 (88.46%) | 668/702 (95.16%) | 677/702 (96.44%) |
| G1_B | 908 | 6441 | 1816 | 0 | 624/702 (88.89%) | 666/702 (94.87%) | 674/702 (96.01%) |
| G2_A | 908 | 11441 | 1816 | 792 | 623/702 (88.75%) | 668/702 (95.16%) | 676/702 (96.30%) |
| G2_B | 908 | 11441 | 1816 | 792 | 624/702 (88.89%) | 666/702 (94.87%) | 676/702 (96.30%) |

B-A within each scale and G2-G1 within each arm have per-query TopK repaired/regressed IDs in [summary.json](summary.json).

Main and same-scale Source comparability: {"G1_source_manifest_equal_AB": true, "G1_source_stream_equal_AB": true, "G2_source_manifest_equal_AB": true, "G2_source_stream_equal_AB": true, "checkpoint_sha256_equal_across_cells": true, "main_log_stream_equal_across_cells": true, "main_stream_sha256_equal_across_cells": true, "manifest_sha256_equal_across_cells": true, "real_auxiliary_stream_equal_across_scales": true}

Single exploratory seed and development only; independent Source G1 differs from historical same-batch Source. Available places and actual exposed places are distinct. No significance or generalization claim.

Source scaling changes its available positive samples and fixed Source-only candidate keys. Qwen samples and fixed bank remain unchanged. Stream checks compare IDs, places and augmentation operation counters, not independent augmented-image byte hashes.

[Frozen plan](experiment_plan.json) · [Status](status.json)
