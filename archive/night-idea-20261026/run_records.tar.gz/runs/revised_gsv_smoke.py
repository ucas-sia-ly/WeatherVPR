"""Bounded four-cell implementation validation; no retrieval/accuracy claim."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/home/admin123/github/WeatherVPR')
sys.path.insert(0, str(ROOT/'scripts'))
import run_stage1_multiseed as runner
import run_token_style_stage2 as common

out = ROOT/'runs/revised_gsv_scale_smoke_20261025'
if out.exists() and any(out.iterdir()):
    raise RuntimeError('Refusing existing smoke output')
out.mkdir(parents=True, exist_ok=True)
args = runner.parse_args(['--output', str(out), '--max-steps', '3', '--skip-evaluation'])
inventory = ROOT/'outputs/revised_plan_20261025/data_inventory'
code = sorted(set((ROOT/'src/weather_vpr').rglob('*.py')) | set((ROOT/'scripts').glob('*.py')) |
              set((ROOT/'configs').glob('*.sh')) |
              set((ROOT/'third_party/salad/workflow').glob('*.py')) |
              set((ROOT/'third_party/salad/models/aggregators').glob('*.py')) |
              set((ROOT/'third_party/dinov2/dinov2').rglob('*.py')))
required = list(inventory.glob('g*_day.jsonl*')) + [Path(__file__), args.checkpoint,
            args.manifest, args.day_bank, args.real_pairs_review, args.real_day_cache,
            args.real_pairs_root/'manifest.jsonl', ROOT/'configs/night_camera.json',
            ROOT/'configs/source_night.json', ROOT/'data/splits/heldout_places.json',
            ROOT/'configs/dino_salad_stage2b_calibration.json']
required += [Path(str(p)+'.json') for p in (args.day_bank,args.real_day_cache)
             if Path(str(p)+'.json').is_file()]
plan = {'purpose': __doc__, 'seed': 42, 'microbatch_limit': 3,
        'expected_updates': 2, 'warmup_updates': 0,
        'code_sha256': {str(p.relative_to(ROOT)):common.digest(p) for p in code},
        'required_files_sha256': {str(p):common.digest(p) for p in required},
        'jobs': {}}
for scale in ('G1', 'G2'):
    for arm in ('A', 'B'):
        name = scale+'_'+arm
        env = runner.arm_environment(args, 42, arm)
        env.update(OUTPUT=str(out/name), GSV_SCALE=scale, GSV_SCALE_ARM=arm,
                   GSV_G1_MANIFEST=str(inventory/'g1_day.jsonl'),
                   GSV_G2_MANIFEST=str(inventory/'g2_day.jsonl'),
                   GSV_G1_CACHE=str(ROOT/'runs/cache/revised_G1_source_day.safetensors'),
                   GSV_G2_CACHE=str(ROOT/'runs/cache/revised_G2_source_day.safetensors'),
                   SOURCE_DAY_BANK_DEVICE='cuda')
        cmd = runner.bounded_command(args, 42, name, 'train')
        cmd[-1] = str(ROOT/'configs/night_gsv_scale.sh')
        plan['jobs'][name] = {'environment': env, 'command': cmd}
common.atomic_json(out/'experiment_plan.json', plan)
results = {}
for name, job in plan['jobs'].items():
    common.verify_frozen_plan(plan)
    common.atomic_json(out/'status.json', {'state':'running','active_job':name})
    env = dict(os.environ, **job['environment'])
    print('Starting '+name, flush=True)
    with (out/(name+'.console.log')).open('w') as console:
        subprocess.run(job['command'], cwd=ROOT, env=env, stdout=console,
                       stderr=subprocess.STDOUT, check=True)
    directory = out/name
    metadata = json.loads((directory/'adapter.json').read_text())
    rows = [json.loads(line) for line in (directory/'training_log.jsonl').read_text().splitlines()]
    assert metadata['optimizer_steps'] == 2 and len(rows) == 3
    assert metadata['student_views'] == {'qwen':12, 'source_night':3,
                                        'real_auxiliary':3 if name.endswith('_B') else 0,
                                        'synthetic_auxiliary':0}
    assert metadata['source_stream']['enabled']
    assert all(r['source_bank_policy']=='separate_source_only' for r in rows)
    assert all(len(r['source_day_sample_ids'])==1 for r in rows)
    results[name] = {'optimizer_steps':metadata['optimizer_steps'],
                     'student_views':metadata['student_views'],
                     'source_stream':metadata['source_stream'],
                     'main_stream_sha256':metadata['main_stream_sha256'],
                     'checkpoint_sha256':metadata['checkpoint_sha256'],
                     'manifest_sha256':metadata['manifest_sha256'],
                     'main_inputs':[[r['main_sample_indices'],r['augmentation']] for r in rows],
                     'source_inputs':[[r['source_day_sample_ids'],r['source_night_augmentation']] for r in rows],
                     'adapter_sha256':common.digest(directory/'adapter.safetensors'),
                     'memory_guard':common.memory_summary(out/f'seed42_{name}.train.memory.jsonl')}
    common.atomic_json(out/'results.json',results)
    print('Finished '+name, flush=True)
assert len({r['main_stream_sha256'] for r in results.values()}) == 1
assert len({r['checkpoint_sha256'] for r in results.values()}) == 1
assert len({r['manifest_sha256'] for r in results.values()}) == 1
assert all(r['main_inputs']==results['G1_A']['main_inputs'] for r in results.values())
assert results['G1_A']['source_inputs']==results['G1_B']['source_inputs']
assert results['G2_A']['source_inputs']==results['G2_B']['source_inputs']
common.atomic_json(out/'status.json',{'state':'complete','checks':{
    'main_stream_equal_all_cells':True,'source_stream_equal_within_scale':True,
    'separate_source_banks':True,'recall_evaluations':0},'accuracy_claim':False})
