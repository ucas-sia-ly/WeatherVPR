import json, re
from pathlib import Path
import torch
from safetensors.torch import load_file
root=Path.cwd(); r=root/'runs/night_token_stage2_smoke_20261025_seed42'
original=torch.load(root/'weights/dino_salad.ckpt',map_location='cpu',weights_only=True)
original=original.get('state_dict',original)
result={}
for arm in ['T0','T1','T2','T3']:
 weights=load_file(str(r/arm/'adapter.safetensors'))
 frozen=changed=0
 for name,value in weights.items():
  ref=original['backbone.'+name]
  match=re.match(r'model.blocks.(\d+)\.',name)
  trainable=bool(match and int(match[1])>=8)
  equal=torch.equal(value,ref)
  if not trainable:
   assert equal, (arm,name)
   frozen+=1
  elif not equal: changed+=1
 assert frozen and changed
 result[arm]={'frozen_tensors_unchanged':frozen,'late4_tensors_changed':changed}
 del weights
print(json.dumps(result,indent=2))
(root/'runs/stage2_implementation_checks/smoke_frozen_weights.json').write_text(json.dumps(result,indent=2))
