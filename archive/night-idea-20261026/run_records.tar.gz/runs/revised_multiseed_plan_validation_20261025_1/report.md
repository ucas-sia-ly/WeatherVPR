# P0 A/B/C multi-seed replication

A: no extra cosine. B: real DarkDriving paired cosine. C: equally weighted extra Qwen paired cosine.

Seed 42 reuses historical T0/T1/C_fast; new seeds start independently from the original Day model.

| Seed | Arm | Origin | Updates | Dev R@1 | R@5 | R@10 |
|---:|---|---|---:|---:|---:|---:|
| 42 | A | historical_seed42_reference_not_new_replication | 908 | 617/702 (87.89%) | 668/702 (95.16%) | 676/702 (96.30%) |
| 42 | B | historical_seed42_reference_not_new_replication | 908 | 622/702 (88.60%) | 667/702 (95.01%) | 675/702 (96.15%) |
| 42 | C | historical_seed42_reference_not_new_replication | 908 | 616/702 (87.75%) | 668/702 (95.16%) | 675/702 (96.15%) |
| 43 | A | new_replication | pending | pending | pending | pending |
| 43 | B | new_replication | pending | pending | pending | pending |
| 43 | C | new_replication | pending | pending | pending | pending |
| 44 | A | new_replication | pending | pending | pending | pending |
| 44 | B | new_replication | pending | pending | pending | pending |
| 44 | C | new_replication | pending | pending | pending | pending |

| Arm | Evaluated seeds | R@1 mean ± sample std | R@5 | R@10 |
|---|---|---:|---:|---:|
| A | [42] | 87.89% ± n/a | 95.16% ± n/a | 96.30% ± n/a |
| B | [42] | 88.60% ± n/a | 95.01% ± n/a | 96.15% ± n/a |
| C | [42] | 87.75% ± n/a | 95.16% ± n/a | 96.15% ± n/a |

Per-query TopK repairs/regressions and paired seed deltas are in [summary.json](summary.json).

This queue evaluates development only. It does not select a test winner, establish route independence, or interpret correlated queries as independent trials. Stream audits compare IDs and operation counters.

[Frozen plan](experiment_plan.json) · [Status](status.json)
