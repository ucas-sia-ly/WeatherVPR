# P0 A/B/C multi-seed replication

A: no extra cosine. B: real DarkDriving paired cosine. C: equally weighted extra Qwen paired cosine.

Seed 42 reuses historical T0/T1/C_fast; new seeds start independently from the original Day model.

| Seed | Arm | Origin | Updates | Dev R@1 | R@5 | R@10 |
|---:|---|---|---:|---:|---:|---:|
| 42 | A | historical_seed42_reference_not_new_replication | 908 | 617/702 (87.89%) | 668/702 (95.16%) | 676/702 (96.30%) |
| 42 | B | historical_seed42_reference_not_new_replication | 908 | 622/702 (88.60%) | 667/702 (95.01%) | 675/702 (96.15%) |
| 42 | C | historical_seed42_reference_not_new_replication | 908 | 616/702 (87.75%) | 668/702 (95.16%) | 675/702 (96.15%) |
| 43 | A | new_replication | 908 | 618/702 (88.03%) | 668/702 (95.16%) | 675/702 (96.15%) |
| 43 | B | new_replication | 908 | 625/702 (89.03%) | 666/702 (94.87%) | 675/702 (96.15%) |
| 43 | C | new_replication | 908 | 617/702 (87.89%) | 667/702 (95.01%) | 676/702 (96.30%) |
| 44 | A | new_replication | 908 | 622/702 (88.60%) | 666/702 (94.87%) | 677/702 (96.44%) |
| 44 | B | new_replication | 908 | 624/702 (88.89%) | 664/702 (94.59%) | 675/702 (96.15%) |
| 44 | C | new_replication | 908 | 621/702 (88.46%) | 667/702 (95.01%) | 675/702 (96.15%) |

| Arm | Evaluated seeds | R@1 mean ± sample std | R@5 | R@10 |
|---|---|---:|---:|---:|
| A | [42, 43, 44] | 88.18% ± 0.38 pp | 95.06% ± 0.16 pp | 96.30% ± 0.14 pp |
| B | [42, 43, 44] | 88.84% ± 0.22 pp | 94.82% ± 0.22 pp | 96.15% ± 0.00 pp |
| C | [42, 43, 44] | 88.03% ± 0.38 pp | 95.06% ± 0.08 pp | 96.20% ± 0.08 pp |

Per-query TopK repairs/regressions and paired seed deltas are in [summary.json](summary.json).

This queue evaluates development only. It does not select a test winner, establish route independence, or interpret correlated queries as independent trials. Stream audits compare IDs and operation counters.

[Frozen plan](experiment_plan.json) · [Status](status.json)
