# Stage-two partial-token style experiment

Fixed T0/T1/T2/T3, original Day initialization, one epoch, seed 42.

| Arm | Real paired cosine | Partial-token style | Updates | SVOX dev R@1 | R@5 | R@10 |
|---|---|---|---:|---:|---:|---:|
| T0 | no | no | 908 | 617/702 (87.89%) | 668/702 (95.16%) | 676/702 (96.30%) |
| T1 | yes | no | 908 | 622/702 (88.60%) | 667/702 (95.01%) | 675/702 (96.15%) |
| T2 | no | yes | 908 | 617/702 (87.89%) | 668/702 (95.16%) | 676/702 (96.30%) |
| T3 | yes | yes | 908 | 622/702 (88.60%) | 667/702 (95.01%) | 675/702 (96.15%) |

Original Day baseline hits (R@1/5/10): 621/668/674 out of 702 queries.

T1_vs_T0, R@1: 7 repaired, 2 regressed.

T2_vs_T0, R@1: 0 repaired, 0 regressed.

T3_vs_T1, R@1: 0 repaired, 0 regressed.

T3_vs_T2, R@1: 7 repaired, 2 regressed.

Integrity: {"main_stream_equal": true, "original_checkpoint_equal": true, "real_auxiliary_stream_equal": true, "source_stream_equal": true, "token_style_choices_equal": true}

Exact view streams, final adapter hashes, diagnostics, and per-query repairs/regressions are in [summary.json](summary.json).

Only SVOX development was evaluated; external tests remain untouched by this queue. One seed cannot establish a stable gain. Main/Source augmentation signatures compare sample IDs and per-step operation counters, not independently rehashed image tensors.

[Frozen plan](experiment_plan.json) · [Status](status.json) · [Previous stage-one report](../../outputs/stage1_results_20261025/report.md)
