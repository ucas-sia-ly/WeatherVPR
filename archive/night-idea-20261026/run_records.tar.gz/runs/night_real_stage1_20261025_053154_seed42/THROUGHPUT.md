# 吞吐优化与任务状态

更新时间：2026-10-25T05:51:57.846984+08:00

- 已完成原 A：908次更新，保留在 `A/`。
- 新队列：`night-real-stage1-20261025-053154-seed42-fast.service`，后台顺序运行 `B_fast/` → `C_fast/`。
- 原 B 在一次性目标缓存尚未完成、尚无优化器更新时停止。原控制台/内存记录保留，未将4对冒烟权重作为初始化。
- 保持 seed42、原始 Day 初始化、Late4、LR1e-6、1 epoch、主微批4/累积2、Source/真实辅助每微批各1。
- 加速：CUDA常驻白天库、免重计算、4个Tensor数据worker、预取1、真实目标batch64/4workers、真实训练只读Night。
- 资源：7GiB RAM硬上限、6GiB回收阈值、2GiB系统余量、任务禁用swap。
- 235项测试通过。新profile前120个主/Source样本和增强记录与原A一致，初始损失容差1e-5。
- 短程稳定吞吐约117.5 Qwen图/秒；原A整轮平均约17.7图/秒，计时口径不同，不作为严格端到端加速比。

实时记录：`B_fast.console.log`、`B_fast/training_log.jsonl`、`C_fast.console.log`、`fast_queue.console.log`。
性能profile与JSON记录见 `throughput/`。本文件是状态快照，实时更新以日志为准。
