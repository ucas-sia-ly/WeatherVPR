from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path.cwd()/'src'))
from weather_vpr.data.real_pairs import ReviewedRealPairs
run=Path(json.loads(Path('runs/stage1_training_latest.json').read_text())['run_root'])
root=Path('data/DarkDriving_Base')
manifest=root/'manifest.jsonl'
source_hash=hashlib.sha256(manifest.read_bytes()).hexdigest()
validation=json.loads((root/'validation.json').read_text())
assert validation['manifest_sha256']==source_hash and validation['errors']==0
rows=[json.loads(line) for line in manifest.read_text().splitlines()]
audit={row['path']:row for row in (json.loads(line) for line in Path('outputs/darkdriving_base_audit/files.jsonl').read_text().splitlines())}
visually_sampled={r['sample_id'] for r in json.loads((run/'visual_audit_samples.json').read_text())}
review=[];rejected=[];night_stats=[]
for row in rows:
    reasons=[]
    for side in ('day','night'):
        record=audit[row[side+'_path']]
        assert record['sha256']==row[side+'_sha256'] and record['pixel_sha256']==row[side+'_pixel_sha256']
        assert not record['errors'] and not record.get('changed_during_read')
        assert record['width']==2448 and record['height']==2048
        if record['std_luma']<=1 or record['black_fraction']>=.995 or record['white_fraction']>=.995:
            reasons.append(side+'_near_informationless')
    night=audit[row['night_path']]
    night_stats.append(night['std_luma'])
    accepted=not reasons
    review.append({
        'sample_id':row['sample_id'],'scene_group':'whole_closed_driving_field_train_only',
        'split':'train','pair_valid':True,'visibility_valid':accepted,
        'review_status':'automatic','reject_reason':None if accepted else ';'.join(reasons),
        'source_manifest_sha256':source_hash,'day_sha256':row['day_sha256'],'night_sha256':row['night_sha256'],
        'review_notes':'Released same-basename pair association + source-bound strict-decode/file/pixel audit. No per-pair geographic or pixel-registration certification. Whole field training only; no internal dev/test.',
        'assistant_visual_sample':row['sample_id'] in visually_sampled,
        'source_sequence_id_for_diagnostics_only':row['sequence_id'],
    })
    if not accepted: rejected.append(row['sample_id'])
path=run/'real_review.jsonl'
with path.open('x') as stream:
    for record in review: stream.write(json.dumps(record,ensure_ascii=False)+'\n')
report={
 'source_pairs':len(rows),'accepted_pairs':sum(r['visibility_valid'] for r in review),
 'rejected_samples':rejected,'review_status':'automatic',
 'visual_sample_count':len(visually_sampled),'visual_sample_filename_groups':23,
 'visual_findings':'Assistant inspected four contact sheets of 200 pairs. Static road/building layout appears corresponding at thumbnail resolution; illumination, glare, occasional foreground differences and small viewpoints vary. No obvious global mismatches found in this sample. Not per-pixel verification or human certification.',
 'screening_rule':'Trust released paired association after signed prior full-resolution strict decoding audit; verify current bytes via ReviewedRealPairs. Reject only std_luma<=1 or >=99.5% near-black/near-white, not ordinary darkness.',
 'night_thumbnail_std_min':min(night_stats),'night_thumbnail_std_max':max(night_stats),
 'scene_policy':'All accepted pairs one conservative train-only field group; no route/location identity inferred; no within-field dev/test; uniform shuffled frame sampling within that group.',
 'limitations':['Near-repeated routes remain, so independent place count is much smaller than frame count.','One GSV epoch samples only approximately 1816 real Night views from the 9520-pair pool.','Use external development protocol and exploratory external evaluation; no test-driven tuning.'],
 'review_manifest_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
 'source_manifest_sha256':source_hash,
}
(run/'data_audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print('Review prepared. Verifying current source image hashes...',flush=True)
pairs=ReviewedRealPairs(root,path)
assert len(pairs)==report['accepted_pairs']
report['current_image_hash_verification_passed']=True
(run/'data_audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
(run/'review_ready.json').write_text(json.dumps({'review_manifest':str(path),'sha256':report['review_manifest_sha256'],'accepted_pairs':len(pairs)},indent=2)+'\n')
print(json.dumps({'accepted_pairs':len(pairs),'rejected_pairs':len(rejected),'visual_sample_count':len(visually_sampled),'ready':True}),flush=True)
