# 阶段一训练启动记录

更新时间：2026-10-25T05:34:55.701448+08:00

- 后台任务：`night-real-stage1-20261025-053154-seed42.service`，与聊天窗口生命周期独立。
- 队列：A 基线 → B 真实配对 → C 合成辅助，逐项串行；任一失败即停止后续组。
- 当前 A：microbatch 599 / 1816，optimizer updates 299 / 908；最新 loss 0.202656。
- 配置：seed 42、Late4、原始 Day 初始化、1 个 GSV epoch、LR 1e-6、BF16。
- 主微批4、累积2、Source/辅助每微批各1；完整更新有效视图约8/2/2。三个组使用相同设置。
- 任务 RAM 上限5 GiB、回收阈值4 GiB，任务禁用swap，保持4 GiB系统余量。
- 真实数据：9520 对，自动来源/完整性核验；另目视抽查200对。全场地仅作train，不宣称逐对人工认证或独立场地内dev/test。
- 数据抽查与规则：`data_audit.json`；训练清单：`real_review.jsonl`；就绪标记：`review_ready.json`。
- A/B/C 各自记录：`<arm>/training_log.jsonl`、`<arm>/adapter.json`、`<arm>/adapter.safetensors`。
- 队列控制台：`queue.console.log`；各组控制台：`<arm>.console.log`；内存：`<arm>.memory.jsonl`。

此文件为启动时快照，后续实时进度以JSONL和systemd状态为准。未启动任何test评估或按test选参。
