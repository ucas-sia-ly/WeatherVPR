import json, subprocess, sys, time
from pathlib import Path
root=Path(__file__).resolve().parents[3]
s=json.loads((root/'runs/stage1_training_latest.json').read_text())
out=Path(__file__).resolve().parent
py='/home/admin123/miniconda3/envs/a2b-lightvpr/bin/python'
results=[]
for dataset,condition in [('tokyo247','night'),('robotcar-public','night'),('robotcar-public','night-rain')]:
 for arm,d in s['arm_output_dirs'].items():
  label=f'{arm}_{dataset}_{condition}'
  cache=root/'runs/cache'/f'{dataset}_day_gallery.safetensors'
  cmd=[py,str(root/'scripts/run_bounded.py'),'--max-gib','7','--high-gib','6','--reserve-gib','2','--log',str(out/(label+'.memory.jsonl')),'--','env','OMP_NUM_THREADS=8','MKL_NUM_THREADS=8',py,str(root/'scripts/evaluate_night_benchmarks.py'),'--dataset',dataset,'--condition',condition,'--adapter-dir',d,'--device','cuda','--retrieval-device','cuda','--batch-size','64','--num-workers','4','--reference-cache-mib','4096','--gallery-cache',str(cache),'--output',str(Path(d)/f'{dataset}_{condition}.json')]
  print('Starting',label,flush=True)
  start=time.monotonic()
  with (out/(label+'.console.log')).open('w') as log:
   code=subprocess.call(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
  results.append({'label':label,'returncode':code,'elapsed_seconds':time.monotonic()-start})
  (out/'external_queue_status.json').write_text(json.dumps(results,indent=2))
  print('Finished',results[-1],flush=True)
  if code: sys.exit(code)
