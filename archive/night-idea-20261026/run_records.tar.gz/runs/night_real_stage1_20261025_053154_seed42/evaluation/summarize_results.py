import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
state = json.loads((ROOT / 'runs/stage1_training_latest.json').read_text())
run = Path(state['run_root'])
plan = json.loads((run / 'evaluation/frozen_evaluation_plan.json').read_text())
out = ROOT / 'outputs/stage1_results_20261025'
out.mkdir(exist_ok=True)
summary = {'run_root': str(run), 'seed': 42, 'training': {}, 'benchmarks': {}}
logs = {}
for arm, directory in state['arm_output_dirs'].items():
    directory = Path(directory)
    digest = hashlib.sha256((directory / 'adapter.safetensors').read_bytes()).hexdigest()
    assert digest == plan['arms'][arm]['weights_sha256']
    metadata = json.loads((directory / 'adapter.json').read_text())
    logs[arm] = [json.loads(line) for line in (directory / 'training_log.jsonl').read_text().splitlines()]
    memory = json.loads((run / (directory.name + '.memory.jsonl')).read_text().splitlines()[-1])
    assert memory['returncode'] == 0 and memory['termination_reason'] is None
    assert not any(isinstance(v, float) and not math.isfinite(v) for row in logs[arm] for v in row.values())
    summary['training'][arm] = {
        'directory': str(directory), 'weights_sha256': digest,
        **{key: metadata[key] for key in ('epochs_completed', 'optimizer_steps', 'steps', 'elapsed_seconds', 'precision', 'peak_cuda_allocated_bytes', 'gradient_checkpointing')},
        'views': logs[arm][-1]['cumulative_student_views'],
        'peak_cgroup_bytes_sampled': memory['peak_cgroup_bytes_sampled'],
    }
keys = ['main_sample_indices', 'source_sample_indices', 'augmentation', 'source_night_augmentation']
assert all(len(rows) == len(logs['A']) and all(all(x[k] == y[k] for k in keys) for x, y in zip(logs['A'], rows)) for rows in logs.values())
summary['input_streams_match'] = True
names = [('SVOX dev', 'svox_train.json'), ('SVOX test', 'svox_test.json'),
         ('Tokyo247 Night', 'tokyo247_night.json'), ('RobotCar public night', 'robotcar-public_night.json'),
         ('RobotCar public night-rain', 'robotcar-public_night-rain.json')]
lines = ['# 阶段一首轮结果（2026-10-25）', '',
         '**结论：真实配对 B 在 SVOX 上有小幅增量，但尚未取得稳定的跨数据集收益。** B 相对 A 的开发 / test Top-1 分别净增 5 / 4 张，相对 C 净增 6 / 2 张；相对原始 SALAD 则都只净增 1 张。Tokyo Top-1 仍低于原始模型 2 张，RobotCar 普通夜间持平、夜雨低 1 张；R@5/10 也没有全面改善。', '',
         '建议保留原始 SALAD 作为使用基线，固定现有配置补齐另外两个 seeds 后再判断是否推进；当前不足以支持阶段二机制或稳定泛化结论。本次未追加训练或依据外部结果调参。', '',
         'seed 42；A/B/C 均训练 1 个 GSV epoch、908 次优化更新。A 无额外配对；B 额外真实配对余弦（0.1）；C 额外合成配对余弦（0.1）。', '',
         '所有检索使用原始 Day SALAD 固定图库、224×224 单尺度、精确排名；没有查询融合。以下均为 Top-1 命中数及 Recall。', '',
         '| 数据集 | 原始 Day | A | B：真实配对 | C：合成配对 |', '| --- | --- | --- | --- | --- |']
for label, filename in names:
    raw = {a: json.loads((Path(p) / filename).read_text()) for a, p in state['arm_output_dirs'].items()}
    baseline = raw['A']['baseline']
    assert all(d['baseline']['recall'] == baseline['recall'] and d['gallery_sha256'] == raw['A']['gallery_sha256'] for d in raw.values())
    evaluations = {'Day': baseline, **{a: d['adapter']['evaluation'] for a, d in raw.items()}}
    result = {'models': {}, 'artifacts': {a: str(Path(p) / filename) for a, p in state['arm_output_dirs'].items()}}
    for model, ev in evaluations.items():
        n = ev['num_evaluated_queries']
        result['models'][model] = {'queries': n, 'recall': ev['recall'], 'hits': {k: round(v * n) for k, v in ev['recall'].items()}}
    comparisons = {}
    for left, right in [('B', 'A'), ('B', 'C'), ('B', 'Day')]:
        def errors(ev):
            assert ev['hard_cases_saved']
            return {r['query_id'] for r in ev['error_queries']}
        old, new = errors(evaluations[right]), errors(evaluations[left])
        comparisons[left + '-' + right] = {'fixed': len(old - new), 'regressed': len(new - old), 'net_hits': len(old) - len(new)}
    result['paired_top1'] = comparisons
    summary['benchmarks'][label] = result
    cells = [f"{v['hits']['R@1']}/{v['queries']} ({100*v['recall']['R@1']:.2f}%)" for v in result['models'].values()]
    lines.append('| ' + label + ' | ' + ' | '.join(cells) + ' |')
lines += ['', '## R@1 / R@5 / R@10 完整命中数', '']
for label, result in summary['benchmarks'].items():
    lines += [f'### {label}', '', '| 模型 | R@1 | R@5 | R@10 |', '| --- | --- | --- | --- |']
    for model, v in result['models'].items():
        lines.append('| ' + model + ' | ' + ' | '.join(str(v['hits'][k]) for k in ('R@1', 'R@5', 'R@10')) + ' |')
    lines += ['', 'B 的逐查询变化（修复 / 新增错误 / 净增）：' + '；'.join(f"相对 {k[2:]}：{v['fixed']} / {v['regressed']} / {v['net_hits']:+d}" for k, v in result['paired_top1'].items()) + '。', '']
lines += ['## 训练与解释边界', '',
          '- 主分支 7263 次视图曝光、Source Night 1816 次；B 另有 1816 个真实样本曝光，C 另有 1816 次合成辅助曝光。DarkDriving 可用池 9520 对，本轮没有遍历全池。',
          '- 已逐条核对 A/B/C 主样本、Source 样本及其增强日志完全一致；最终权重哈希与评估前冻结计划一致。所有训练正常退出，日志浮点标量有限。',
          '- A 使用优化前的 CPU bank / 激活检查点，B/C 使用 GPU bank / 无检查点。输入流已验证一致；完整训练没有验证逐位数值等价，微小差异存在执行后端这一限制。',
          '- 本轮只有 seed 42；SVOX test 和外部集合已有历史结果，属于探索性比较。RobotCar public 为自定义公开位姿检索协议，不是官方定位成功率。',
          '- DarkDriving 使用单一整场地 train-only 分组，尚无可靠路线隔离开发集；9520 对通过完整性检查，人工缩略图抽查 200 对，未逐对人工认证或独立认证与外部评估无地理重合。',
          '- 总损失包含不同辅助项，不能直接比较 A/B/C 的 total loss 来判断好坏。', '']
for a, v in summary['training'].items():
    lines.append(f"- {a}：记录耗时 {v['elapsed_seconds']:.1f} 秒；采样峰值任务 RAM {v['peak_cgroup_bytes_sampled']/1024**3:.2f} GiB；PyTorch 峰值已分配显存 {v['peak_cuda_allocated_bytes']/1024**3:.2f} GiB。B 包含首次真实 Day 缓存构建，A/B/C 耗时不能直接当作相同后端的速度对照。")
(out / 'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False))
(out / 'report.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({label: r['models'] for label, r in summary['benchmarks'].items()}, indent=2, ensure_ascii=False))
