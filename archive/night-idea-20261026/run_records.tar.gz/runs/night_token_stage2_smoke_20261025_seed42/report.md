# Stage-two partial-token style experiment

Fixed T0/T1/T2/T3, original Day initialization, one epoch, seed 42.

| Arm | Real paired cosine | Partial-token style | Updates | SVOX dev R@1 | R@5 | R@10 |
|---|---|---|---:|---:|---:|---:|
| T0 | no | no | 2 | pending | pending | pending |
| T1 | yes | no | 2 | pending | pending | pending |
| T2 | no | yes | 2 | pending | pending | pending |
| T3 | yes | yes | 2 | pending | pending | pending |

Integrity: {"main_stream_equal": true, "original_checkpoint_equal": true, "real_auxiliary_stream_equal": true, "source_stream_equal": true, "token_style_choices_equal": true}

Exact view streams, final adapter hashes, diagnostics, and per-query repairs/regressions are in [summary.json](summary.json).

Only SVOX development was evaluated; external tests remain untouched by this queue. One seed cannot establish a stable gain. Main/Source augmentation signatures compare sample IDs and per-step operation counters, not independently rehashed image tensors.

[Frozen plan](experiment_plan.json) · [Status](status.json) · [Previous stage-one report](../../outputs/stage1_results_20261025/report.md)
